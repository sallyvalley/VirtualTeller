package transaction_processor;

import java.io.*;
import java.util.Scanner;
import java.util.Date;


public class VirtualTeller {
	
	static int x = 0;
	static String bankname = "Bank of the ABQ";
	static String bankAddress = "132 Broadway, Albuquerque New Mexico";
	static String Customer_data[] = new String[10];
	Scanner scnnr = new Scanner(System.in);
	Date date = new Date();
	
	
	
	public static void main(String[] args) {
				
		ReadFile r = new ReadFile();
		r.file_read();
		
		Account id = new Account();
		id.login();
		
		VirtualTeller menu = new VirtualTeller();
		menu.menu_select();
		
	}
	
	public void menu_select() {
		Transaction tran = new Transaction();
		VirtualTeller menu = new VirtualTeller();
		
		System.out.println("Welcome to your " + Customer_data[1] + " account!");
		System.out.println(date);
		System.out.println("\n Please input a number for your desired action:");
		System.out.println("\n Input 1 to deposit funds, input 2 to withdraw, input 3 to display balances, input 4 to transfer, input 5 to terminate.");
		
		int selection = scnnr.nextInt();
		
		if (selection == 1) {
			tran.deposit();
		}
		else if (selection == 2) {
			tran.withdraw();
		}
		else if (selection == 3) {
			
			System.out.println("\n" + "Account number: " + Customer_data[4] + " " +  Customer_data[1] + ": " + Customer_data[2]);
			System.out.println("Account number: " + Customer_data[5] + " " + Customer_data[6] + ": " + Customer_data[7] + "\n");
			System.out.println("Input 1 to complete another transaction, input 2 to terminate!");
			
			int sel = scnnr.nextInt();
			if (sel == 1) {
				menu.menu_select();
			} else {
				System.out.println("Have a nice day!");
				System.exit(1);
			}
			
		}
		else if (selection == 4) {
			tran.transfer();
		}
		else if (selection == 5) {
			System.out.println("Have a nice day!");
			System.exit(1);
		}
		else {
			System.out.println("Invalid Selection!");
		}	
	}
}

class Receipt extends VirtualTeller {
	public void printReceipt() {
		VirtualTeller menu = new VirtualTeller();
		Receipt writer = new Receipt();
		
		try {
		PrintWriter outputFile = new PrintWriter("customertxt.txt");
		int i;
		for (i=0; i < 8; ++i) {
			outputFile.println(Customer_data[i]);
		}
		outputFile.close();
		}catch (FileNotFoundException e)
    	{
    		System.out.println("Could not find file!");
    	}
		
		
		System.out.println("--------------------------------");
		System.out.println("********\\ Receipt /********");
		System.out.println("****\\ " + bankname + " /****");
		System.out.println(bankAddress);
		System.out.println(date);
		System.out.println(Customer_data[8]);
		System.out.println(Customer_data[9]);
		System.out.println(Customer_data[1] + " Account");
		System.out.println("Current Balance: $" + Customer_data[2]);
		System.out.println(Customer_data[6] + " Account");
		System.out.println("Current Balance: $" + Customer_data[7]);
		System.out.println("Input 1 to complete another transaction, input 2 to terminate!");
		System.out.println("--------------------------------");
		writer.receipttoFile();
		
		int selection = scnnr.nextInt();
		if (selection == 1) {
			menu.menu_select();
		} else {
			System.out.println("Have a nice day!");
			System.exit(1);
		}
	}
	
	public void receipttoFile() {

		try {
		PrintWriter outputFile = new PrintWriter("receipts.txt");
		outputFile.println("--------------------------------");
		outputFile.println("********\\ Receipt /********");
		outputFile.println("****\\ " + bankname + " /****");
		outputFile.println(date);
		outputFile.println(Customer_data[1] + " Account");
		outputFile.println("Current Balance: $" + Customer_data[2]);
		outputFile.println(Customer_data[6] + " Account");
		outputFile.println("Current Balance: $" + Customer_data[7]);
		outputFile.println("Input 1 to complete another transaction, input 2 to terminate!");
		outputFile.println("--------------------------------");
		outputFile.close();
		}catch (FileNotFoundException e)
    	{
    		System.out.println("Could not find file!");
    	}
	}
}


class ReadFile extends VirtualTeller {  
	
    public void file_read()  {
    	try {
    	Scanner input = new Scanner (new File("customertxt.txt"));
    	int x=0;
    		while (input.hasNextLine()){
    			Customer_data[x] = input.nextLine();
    			x = x+1;
    		}
    	}catch (FileNotFoundException e)
    	{
    		System.out.println("Could not find file!");
    	}   	
   }    
}  


class Account extends VirtualTeller{
	public void login() {
		VirtualTeller menu = new VirtualTeller();
		int storedID=0;
		int storedPIN=0;
		int i;
		storedID = Integer.parseInt(Customer_data[0]);
		storedPIN = Integer.parseInt(Customer_data[3]);
		System.out.println("*************************************************");
		System.out.println("Welcome to Bank of the ABQ's Virtual Teller Tool:");
		System.out.println("The complete banking experience, at your fingertips!\n");
		System.out.println("Please enter your customer ID and PIN.");
		System.out.println("Warning: Three incorrect login attempts will terminate the program!\n");
		System.out.println("*************************************************\n");
		for (i=0; i < 3; ++i) {
			System.out.println("Please enter your customer ID:");
			int customer_id = scnnr.nextInt();
			System.out.println("Please enter your customer PIN:");
			int customer_pin = scnnr.nextInt();
			if ((customer_id == storedID) && (customer_pin == storedPIN)) {
				menu.menu_select();
				break;
			} else {
				System.out.println("Login Failed! Please try again.");
			}
		}
		System.out.println("Login Failed!");
		System.exit(1);
		
	}
}

class Transaction extends VirtualTeller{
	VirtualTeller menu = new VirtualTeller();
	Receipt print = new Receipt();
	
	public void deposit() {
		System.out.println("Enter the amount you'd like deposited: ");
		int deposit = scnnr.nextInt();
		int total=0;
		total = Integer.parseInt(Customer_data[2]);
		Customer_data[2] = String.valueOf(total + deposit);
		System.out.println("\n Amount deposited! \n");
		print.printReceipt();
		
	}
	
	public void withdraw() {
		System.out.println("Enter the amount you'd like withdrawn: ");
        int withdraw = scnnr.nextInt();
        int total=0;
        total = Integer.parseInt(Customer_data[2]);
        Customer_data[2] = String.valueOf(total - withdraw);
        System.out.println("\n Amount withdrawn! \n");
        print.printReceipt();
        
	}
	
	public void transfer(){
		Transaction tran = new Transaction();
		int storednum = Integer.parseInt(Customer_data[5]);
        System.out.println("Enter the Transfer Amount");
        int transfer = scnnr.nextInt();
        System.out.println("Enter the Transfer Account Number");
        int accountnum = scnnr.nextInt();
        if (storednum == accountnum) {
             int total1 = Integer.parseInt(Customer_data[2]);
             int total2 = Integer.parseInt(Customer_data[7]);
             Customer_data[2] =  String.valueOf(total1+transfer);
             Customer_data[7] =  String.valueOf(total2-transfer);
             System.out.println("\n Amount transferred! \n");
             print.printReceipt();
        } else {
        	System.out.println("Invalid account number! Please try again.");
        	tran.transfer();
        }
       
        
           
    }
}







